using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;

//This namespace holds Add ons in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.AddOns
{
    public class AccountLocker : NinjaTrader.NinjaScript.AddOnBase
    {
        private double profitTarget = 400; // Set the default PnL threshold value here
        private double lossTarget = -240.0;  // Set the default Loss Target value here
        private string logFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader_AccountLockerLogs");
        private StreamWriter logFileWriter;
        private DateTime currentLogDate;
		private HashSet<string> lockedAccounts = new HashSet<string>();

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"This add-on cancels all active orders.";
                Name = "AccountLocker";
				ResetLockedAccounts();
            }
            else if (State == State.Configure)
            {
                Directory.CreateDirectory(logFolder);
                OpenLogFile();
                Log("AccountLocker Add-On: Configuring...");
                //PrintDailyPnL();
                LockAccounts(profitTarget, lossTarget);
                Log("AccountLocker Add-On: Finished configuration.");
            }
            else if (State == State.Active)
            {
                // Subscribe to the account item update event for all accounts
                foreach (Account account in Account.All)
                {
                    account.AccountItemUpdate += OnAccountItemUpdate;
                    account.OrderUpdate += OnOrderUpdate;
                }
                Log("AccountLocker Add-On: Monitoring started.");
            }
            else if (State == State.Terminated)
            {
                // Unsubscribe from the account item update event for all accounts
                foreach (Account account in Account.All)
                {
                    account.AccountItemUpdate -= OnAccountItemUpdate;
                    account.OrderUpdate -= OnOrderUpdate;
                }
                Log("AccountLocker Add-On: Monitoring stopped.");
                CloseLogFile();
            }
        }

        private void OnAccountItemUpdate(object sender, AccountItemEventArgs e)
        {
            if (e.AccountItem == AccountItem.RealizedProfitLoss)
            {
                Account account = sender as Account;
                if (account != null && !lockedAccounts.Contains(account.Name))
                {
                    double realizedPnL = account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
                    Log($"AccountLocker Add-On: Account {account.Name} PnL updated to {realizedPnL} USD");

                    if (realizedPnL >= profitTarget || realizedPnL <= lossTarget){
						LockAccount(account, realizedPnL);
					}
                    
                }
            }
        }

        private void OnOrderUpdate(object sender, OrderEventArgs e)
		{
		    Account account = sender as Account;
		    if (account != null)
		    {
		        double realizedPnL = account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
		
		        if (realizedPnL >= profitTarget || realizedPnL <= lossTarget)
		        {
		            if (!lockedAccounts.Contains(account.Name))
		            {
		                //Log($"AccountLocker Add-On: Realized PnL for account {account.Name} is {realizedPnL} USD, which meets the target. Locking account...");
		                LockAccount(account, realizedPnL);
		            }
		            else
		            {
		                //Log($"AccountLocker Add-On: Account {account.Name} is already locked. Cancelling any remaining orders...");
		                CancelAllOrders(account);
						CloseAllPositions(account);
		            }
		        }
		    }
		}

        private void PrintDailyPnL()
        {
            Log("AccountLocker Add-On: Printing daily PnL for each account...");

            foreach (Account account in Account.All)
            {
                Log($"AccountLocker Add-On: Account: {account.Name}, Daily PnL: {account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar)} USD");
            }

            Log("AccountLocker Add-On: Finished printing daily PnL.");
        }

        private void LockAccounts(double profitTarget, double lossTarget)
		{
		    Log($"AccountLocker Add-On: Checking accounts with realized PnL >= {profitTarget} USD or <= {lossTarget} USD...");
		
		    foreach (Account account in Account.All)
		    {
		        double realizedPnL = account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar);
		
		        if (realizedPnL >= profitTarget || realizedPnL <= lossTarget)
		        {
		            LockAccount(account, realizedPnL);
		        }
		        else
		        {
		            Log($"AccountLocker Add-On: Account {account.Name} has realized PnL: {realizedPnL} USD, no need to lock.");
		        }
		    }
		
		    Log("AccountLocker Add-On: Finished checking accounts.");
		}
		
		private void LockAccount(Account account, double realizedPnL)
		{
		    if (lockedAccounts.Contains(account.Name))
		    {
		        Log($"AccountLocker Add-On: Account {account.Name} is already locked. Skipping...");
		        return;
		    }
		
		    if (realizedPnL >= profitTarget)
		    {
		        Log($"AccountLocker Add-On: Account {account.Name} has realized PnL: {realizedPnL} USD, meeting profit target. Canceling all orders...");
		        CancelAllOrders(account);
		    }
		    else if (realizedPnL <= lossTarget)
		    {
		        Log($"AccountLocker Add-On: Account {account.Name} has realized PnL: {realizedPnL} USD, meeting loss target. Canceling all orders and closing all positions...");
		        CancelAllOrders(account);
		        CloseAllPositions(account);
		    }
		
		    lockedAccounts.Add(account.Name);
		}

		private void ResetLockedAccounts()
		{
		    lockedAccounts.Clear();
		    Log("AccountLocker Add-On: Locked accounts list has been reset.");
		}

        private void CancelAllOrders(Account account)
        {
            Log($"AccountLocker Add-On: Starting to cancel orders for account {account.Name}...");

            List<Order> ordersToCancel = account.Orders
                .Where(order => (order.OrderState == OrderState.Working || 
                                 order.OrderState == OrderState.Accepted) &&
                                 order.Name == "Entry")
                .ToList();

            Log($"AccountLocker Add-On: Found {ordersToCancel.Count} orders");
			
			if(ordersToCancel.Count == 0)
			{
				return;
			}

            foreach (Order order in ordersToCancel)
            {
                try
                {
                    Log($"AccountLocker Add-On: Attempting to cancel order ID {order.OrderId}, State: {order.OrderState}, Name: {order.Name}");
                    account.Cancel(new[] { order });
                    Log($"AccountLocker Add-On: Cancellation request sent..");
                }
                catch (Exception ex)
                {
                    Log($"AccountLocker Add-On: Error cancelling order ID {order.OrderId}: {ex.Message}");
                }
            }

            Log($"AccountLocker Add-On: Finished cancelling orders.");
        }

        private void CloseAllPositions(Account account)
        {
            Log($"AccountLocker Add-On: Starting to close all positions for account {account.Name}...");

            foreach (Position position in account.Positions)
            {
                if (position.Quantity != 0)
                {
                    try
                    {
                        Log($"AccountLocker Add-On: Attempting to close position for instrument {position.Instrument.FullName}, Quantity: {position.Quantity}");
                        
                        // Create a collection with a single instrument
                        ICollection<Instrument> instrumentCollection = new List<Instrument> { position.Instrument };
                        
                        account.Flatten(instrumentCollection);
                        Log($"AccountLocker Add-On: Close request sent for position in {position.Instrument.FullName}");
                    }
                    catch (Exception ex)
                    {
                        Log($"AccountLocker Add-On: Error closing position for instrument {position.Instrument.FullName}: {ex.Message}");
                    }
                }
            }

            Log($"AccountLocker Add-On: Finished closing all positions for account {account.Name}.");
        }

        private void Log(string message)
        {
            Print(message); // Existing console logging

            // File logging
            try
            {
                // Check if the log date has changed and rotate the log file if necessary
                if (DateTime.Now.Date != currentLogDate)
                {
                    RotateLogFile();
                }

                if (logFileWriter != null)
                {
                    logFileWriter.WriteLine($"{DateTime.Now}: {message}");
                    logFileWriter.Flush();
                }
            }
            catch (Exception ex)
            {
                Print($"AccountLocker Add-On: Error writing to log file: {ex.Message}");
            }
        }

        private void RotateLogFile()
        {
            try
            {
                // Close the current log file
                logFileWriter?.Close();

                // Update the current log date
                currentLogDate = DateTime.Now.Date;

                // Create a new log file path with the current date
                string newLogFilePath = Path.Combine(logFolder, $"AccountLockerLog_{currentLogDate:yyyyMMdd}.txt");

                // Open a new log file
                logFileWriter = new StreamWriter(newLogFilePath, true);
                Log("AccountLocker Add-On: Log file rotated.");
            }
            catch (Exception ex)
            {
                Print($"AccountLocker Add-On: Error rotating log file: {ex.Message}");
            }
        }

        private void OpenLogFile()
        {
            try
            {
                // Update the current log date
                currentLogDate = DateTime.Now.Date;

                // Create a new log file path with the current date
                string logFilePath = Path.Combine(logFolder, $"AccountLockerLog_{currentLogDate:yyyyMMdd}.txt");

                logFileWriter = new StreamWriter(logFilePath, true);
                Log("AccountLocker Add-On: Log file opened.");
            }
            catch (Exception ex)
            {
                Print($"AccountLocker Add-On: Error opening log file: {ex.Message}");
            }
        }

        private void CloseLogFile()
        {
            try
            {
                if (logFileWriter != null)
                {
                    Log("AccountLocker Add-On: Log file closing.");
                    logFileWriter.Close();
                    logFileWriter = null;
                }
            }
            catch (Exception ex)
            {
                Print($"AccountLocker Add-On: Error closing log file: {ex.Message}");
            }
        }
    }
}
